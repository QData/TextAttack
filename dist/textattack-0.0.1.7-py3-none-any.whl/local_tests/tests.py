tests = []

import python_function_tests
tests.extend(python_function_tests.tests)

import command_line_tests
tests.extend(command_line_tests.tests)