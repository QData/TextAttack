from .language_tool import LanguageTool
from .part_of_speech import PartOfSpeech