from .mnli import MNLI
from .snli import SNLI