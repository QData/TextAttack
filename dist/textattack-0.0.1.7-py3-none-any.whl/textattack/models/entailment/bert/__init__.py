from .bert_for_mnli import BERTForMNLI
from .bert_for_snli import BERTForSNLI