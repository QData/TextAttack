class Logger:
    def __init__(self):
        pass

    def log_attack_result(self, result, examples_completed):
        pass

    def log_rows(self, rows, title, window_id):
        pass

    def log_hist(self, arr, numbins, title, window_id):
        pass

    def log_sep(self):
        pass

    def flush(self):
        pass

